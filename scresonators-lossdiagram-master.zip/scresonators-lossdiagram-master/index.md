---
layout: default
---
<!--![removal ai _tmp-649b3bb3d9e42](https://github.com/DylanBlevins49/scresonators-lossdiagram/assets/120617602/34c51588-3268-4268-a8d0-c5940d346009)
![removal ai _8da2c77d-1255-4551-82ba-e6fe34f9ac49](https://github.com/DylanBlevins49/scresonators-lossdiagram/assets/120617602/3c1cb023-e2ac-4594-aaa0-ce455eba280f)-->
<!--<div class="row">
  <div class="column">
    <img src="https://github.com/DylanBlevins49/scresonators-lossdiagram/assets/120617602/34c51588-3268-4268-a8d0-c5940d346009" alt="NIST" style="width:30%">
  </div>
  <div class="column">
    <img src="https://github.com/DylanBlevins49/scresonators-lossdiagram/assets/120617602/3c1cb023-e2ac-4594-aaa0-ce455eba280f" alt="BCQT" style="width:30%">
  </div>
  <div class="column">
    <img src="https://github.com/DylanBlevins49/scresonators-lossdiagram/assets/120617602/e182f013-b513-490b-a707-8dc45a86408a" alt="CU Boulder" style="width:30%">
  </div>
</div>
<body>
<div class = "parent">
<div>
<img src="https://github.com/DylanBlevins49/scresonators-lossdiagram/assets/120617602/9e095206-c147-44e9-b251-aa130561769c">
</div>
<div>
<img src="https://github.com/DylanBlevins49/scresonators-lossdiagram/assets/120617602/e5a4fb56-1025-429b-b335-473f7bfc9f6b">
</div>
</body>
.parent{
display: grid;
grid-template-columns: 1fr 1fr 1fr;
column-gap: 5px;
}-->
![LOGOS SEE Through](https://github.com/DylanBlevins49/scresonators-lossdiagram/assets/120617602/390ab844-ebd0-4a17-91e1-c3cc5e564588)
* * *
<p> <b>Superconducting qubits are coherence-limited by materials losses, but the lack of comparable interlaboratory metrics is stunting progress towards lower loss devices. Here, we compile resonator loss measurements from literature and attempt to compare them by scaling loss by the gap of the coplanar waveguide resonator to account for participation of the lossy material. This resource is intended for use by researchers interested in building higher performance materials stacks for superconducting quantum devices.</b> </p>


<br>
<br>
# CPW Resonator Loss 
* * *
![New plotly symbol legend](https://github.com/DylanBlevins49/scresonators-lossdiagram/assets/120617602/5248d3ab-a07a-4a9f-bf25-89599540bb04)
<p align="left"><iframe id="igraph" scrolling="no" style="border:none;" seamless="seamless" align="center" src="https://plotly.com/~dylanblevins49/3.embed" height="650" width="136%"></iframe></p>
<!--<p align="center"><iframe src="http://www.google.com/" width=500 height="500"></iframe></p>-->
<br>
<br>
# Dataset
* * *
<!--| SC    | Reference                | Dep.	         |Substrate	 | δLP      | Fδ0TLS   |  g (µm) |
|:------|:-------------------------|:--------------|:----------|:---------|:---------|:--------|
| Nb    |	Gao et al. (2008c)	     | Not Specified | Al2O3     |          | 2.40E-06 | 33      |
| Nb    |	Kumar et al. (2008)	     | Not Specified | Si		     |          | 2.94E-05 | 1       |
| Re    |	Wang et al. (2009)       | E-beam	       | Al2O3     | 1.00E-06	|	         | 6.4     |
| Al    |	Wang et al. (2009)	     | Sputter	     | Al2O3     | 3.00E-06	|	         | 6.4     |
| NbTiN |	Barends et al. (2010)	   | Sputter       | Si	       | 3.00E-06	|	         | 2       |
| Ta    |	Barends et al. (2010)	   | Sputter	     | Si	       | 3.00E-05	|	         | 2       |
| Nb    |	Macha et al. (2010)	     | Not Specified | Al2O3     |          | 2.40E-06 | 30      |
| Nb    |	Macha et al. (2010)	     | Not Specified | Si        |          | 1.30E-06 | 30      |
| Al    |	Macha et al. (2010)      | Not Specified | Al2O3     |          | 2.00E-06 | 30      |
| TiN   |	Vissers et al. (2010)    | Sputter	     | Al2O3     | 3.00E-05	|          | 2       |
| TiN   |	Vissers et al. (2010)	   | Sputter	     | Al2O3     | 2.00E-05	|	         | 2       |
|TiN    | Vissers et al. (2010)	   | Sputter	     | Al2O3     | 1.00E-05	|	         | 2       |
| TiN   |	Vissers et al. (2010)	   | Sputter	     | Si	       | 2.00E-06	|          | 2       |
| Nb    |	Wisbey et al. (2010)	   | Not Specified | Si		     |          | 1.30E-05 | 2       |
| Nb    | Wisbey et al. (2010)	   | Not Specified | Si		     |          | 7.00E-06 | 2       |
| Nb    |	Sage et al. (2011)	     | Sputter       | Si		     |          | 1.50E-05 | 5       |
| Nb	  | Sage et al. (2011)	     | Sputter	     | Al2O3     |          | 1.80E-05 | 5       |
| Al	  | Sage et al. (2011)	     | Sputter	     | Si		     |          | 1.50E-06 | 5       |
| Al	  | Sage et al. (2011)	     | Sputter	     | Al2O3     |          | 1.60E-06 | 5       |
| Al	  | Sage et al. (2011)	     | MBE	         | Al2O3     |          | 1.80E-06 | 5       |
| Re	  | Sage et al. (2011)	     | MBE	         | Al2O3     |          | 1.80E-06 | 5       |
| TiN	  | Sage et al. (2011)	     | Sputter	     | Si		     |          | 9.60E-07 | 5       |
| Al	  | Megrant et al. (2012)	   | Sputter       | Al2O3     | 2.50E-06	|          | 2       |
| Al	  | Megrant et al. (2012)	   | E-beam        | Al2O3     | 1.40E-06	|	         | 2       |
| Al	  | Megrant et al. (2012)	   | MBE           | Al2O3     | 5.80E-07	|	         | 2       |
| TiN	  | Ohya et al. (2013)	     | Sputter	     | Si	       | 1.00E-06	|          | 10      |
| Nb	  | Goetz et al. (2016) 	   | Sputter	     | Si	       |          | 9.00E-07 | 12      |
| Nb	  | Goetz et al. (2016)	     | Sputter	     | Al2O3     |          | 1.60E-06 | 12      |
| Al	  | Richardson et al. (2016) |	MBE	         | Si		     |          | 2.00E-07 | 12      |
| Al	  | Richardson et al. (2016) |	MBE	         | Si		     |          | 5.00E-07 | 12      |
| Al	  | Richardson et al. (2016) |	MBE	         | Al2O3     |          | 5.00E-07 | 12      |
| Al	  | Richardson et al. (2016) |	MBE	         | Al2O3     |          | 4.00E-07 | 2       |
| NbN	  | De Graaf et al. (2018)	 | Sputter	     | Al2O3     |          | 1.04E-05 | 2       |
| NbN	  | De Graaf et al. (2018)	 | Sputter	     | Al2O3     |          | 7.44E-06 | 2       |
| TiN	  | Calusine et al. (2018)	 | Sputter	     | Si        |          | 3.00E-07 | 11      |
| Al	  | Earnest et al. (2018)	   | E-beam        | Si	       | 3.10E-06 |	3.27E-06 | 9       |
| Al	  | Earnest et al. (2018)	   | E-beam	       | Si	       | 1.90E-06	| 1.53E-06 | 9       |
| Al	  | Earnest et al. (2018)	   | E-beam	       | Si	       | 1.80E-06	| 1.56E-06 | 9       |
| Al	  | Earnest et al. (2018)	   | E-beam	       | Si	       | 1.20E-06	| 8.00E-07 | 9       |
| In	  | McRae et al. (2018)	     | Therm. Evap.	 | Si		     |          | 4.00E-05 | 6       |
| In	  | McRae et al. (2018)	     | Therm. Evap.	 | Si		     |          | 5.00E-05 | 6       |
| TiN	  | Lock et al. (2019)	     | Sputter	     | Si		     |          | 2.00E-07 | 12      |
| Nb	  | Kowsari et al. (2021)	   | E-beam	       | Si		     |          | 3.00E-07 | 2       |
| Nb	  | Zheng et al. (2022)	     | E-beam	       | Si		     |          | 2.90E-07 | 2       |
| TiN	  | Gao et al. (2022)	       | Sputter	     | Al2O3     |	        | 3.00E-07 | 6       |
| Ta	  | Shi et al. (2022)	       | Sputter	     | Al2O3     |	        | 1.00E-06 | 5       |
| Ta	  | Lozano et al. (2022)	   | Sputter	     | Si		     |          | 4.00E-07 | 4.5     |
| Ta	  | Lozano et al. (2022)	   | Sputter	     | Si		     |          | 1.00E-06 | 4.5     |-->


![image](https://github.com/DylanBlevins49/scresonators-lossdiagram/assets/120617602/05bd47ce-c54c-4d0d-9217-6b84f0aad62a)

<br>
<br>
# References
* * *
<br>
Calusine, G., Melville, A., Woods, W., Das, R., Stull, C., Bolkhovsky, V., Braje, D., Hover, D., Kim, D. K., Miloshi, X. et al., "*Analysis and mitigation of interface losses in trenched superconducting coplanar waveguide resonators*" Appl. Phys. Lett. **112**, 062601 (2018).<a href="https://pubs.aip.org/aip/apl/article/112/6/062601/35936/Analysis-and-mitigation-of-interface-losses-in" target="_blank" rel="noopener noreferrer"><i> View Reference </i></a>.<br>

De Graaf, S., Faoro, L., Burnett, J., Adamyan, A., Tzalenchuk, A. Y., Kubatkin, S., Lindström, T., and Danilov, A., “*Suppression of low-frequency charge noise in superconducting resonators by surface spin desorption*”, Nat. Commun. **9**, 1143 (2018).<a href="https://www.nature.com/articles/s41467-018-03577-2" target="_blank" rel="noopener noreferrer"><i> View Reference </i></a>.<br>

Earnest, C. T., Béjanin, J. H., McConkey, T. G., Peters, E. A., Korinek, A., Yuan, H., and Mariantoni, M., “*Substrate surface engineering for high-quality silicon/aluminium superconducting resonators,*” Supercond. Sci. Technol. **31**, 125013 (2018).<a href="https://arxiv.org/abs/1807.08072" target="_blank" rel="noopener noreferrer"><i> View Reference </i></a>.<br>

Gao, R., Yu, W., Deng, H., Ku, H.-S., Zhisheng, L., Wang, M., Miao, X., Lin, Y., & Deng, C. (2022). "*Epitaxial titanium nitride microwave resonators: Structural, chemical, electrical, and microwave properties,*" **6(3)**.<a href="https://arxiv.org/abs/2111.04227" target="_blank" rel="noopener noreferrer"><i> View Reference </i></a>.<br>

Goetz, J., Deppe, F., Haeberlein, M., Wulschner, F., Zollitsch, C. W., Meier, S., Fischer, M., Eder, P., Xie, E., Fedorov, K. G. et al., “*Loss mechanisms in superconducting thin film microwave resonators,*” J. Appl. Phys. **119**, 015304 (2016).<a href="https://pubs.aip.org/aip/jap/article-abstract/119/1/015304/141819/Loss-mechanisms-in-superconducting-thin-film?redirectedFrom=fulltext" target="_blank" rel="noopener noreferrer"><i> View Reference</i></a>.<br>

Kowsari, D., K. Zheng, J. T. Monroe, N. J. Thobaben, X. Du, P. M. Harrington, E. A. Henriksen, D. S. Wisbey, K. W. Murch; "*Fabrication and surface treatment of electron-beam evaporated niobium for low-loss coplanar waveguide resonators,*" Appl. Phys. Lett. **27** , September 2021; 119 (13): 132601.<a href="https://pubs.aip.org/aip/apl/article/119/13/132601/40997/Fabrication-and-surface-treatment-of-electron-beam" target="_blank" rel="noopener noreferrer"><i> View Reference </i></a>.<br>

Kumar, S., Gao, J., Zmuidzinas, J., Mazin, B. A., LeDuc, H. G., and Day, P. K., “*Temperature dependence of the frequency and noise of superconducting coplanar waveguide resonators,*” Appl. Phys. Lett. **92(12)**, 123503 (2008).<a href="https://pubs.aip.org/aip/apl/article-abstract/92/12/123503/334498/Temperature-dependence-of-the-frequency-and-noise?redirectedFrom=fulltext" target="_blank" rel="noopener noreferrer"><i> View Reference </i></a>.<br>

Lock, E. H., Xu, P., Kohler, T., Camacho, L., Prestigiacomo, J., Rosen, Y. J., and Osborn, K. D., “*Using surface engineering to modulate superconducting coplanar microwave resonator performance,*” IEEE Trans. Appl. Supercond. **29**, 1700108 (2019).<a href="https://ieeexplore.ieee.org/document/8606149" target="_blank" rel="noopener noreferrer"><i> View Reference </i></a>.<br>

Lozano, D. P., M. Mongillo , X. Piao , S. Couet , D. Wan , Y. Canvel , A. M. Vadiraj , Ts. Ivanov, J. Verjauw, R. Acharya, J. Van Damme, F. A. Mohiyaddin, J. Jussot, P. P. Gowda, A. Pacco, B. Raes, J. Van de Vondel, I. P. Radu, B. Govoreanu1 J. Swerts, A. Potočnik, and K. De Greve, “*Manufacturing high-Q superconducting α-tantalum resonators on silicon wafers*”, (2023)<a href="https://arxiv.org/abs/2211.16437" target="_blank" rel="noopener noreferrer"><i> View Reference </i></a>.<br>

Macha, P., van Der Ploeg, S. H. W., Oelsner, G., Il’ichev, E., Meyer, H.-G., Wünsch, S., and Siegel, M., “*Losses in coplanar waveguide resonators at millikelvin temperatures,*” Appl. Phys. Lett. **96(6)**, 062503 (2010).<a href="https://pubs.aip.org/aip/apl/article-abstract/96/6/062503/167025/Losses-in-coplanar-waveguide-resonators-at?redirectedFrom=fulltext" target="_blank" rel="noopener noreferrer"><i> View Reference </i></a>.<br>

McRae, C. R. H., Béjanin, J. H., Earnest, C. T., McConkey, T. G., Rinehart, J. R., Deimert, C., Thomas, J. P., Wasilewski, Z. R., and Mariantoni, M., “*Thin film metrology and microwave loss characterization of indium and aluminum/indium superconducting planar resonators,*” J. Appl. Phys. **123(20)**, 205304 (2018).<a href="https://pubs.aip.org/aip/jap/article-abstract/123/20/205304/155631/Thin-film-metrology-and-microwave-loss?redirectedFrom=fulltext" target="_blank" rel="noopener noreferrer"><i> View Reference </i></a>.<br>

Megrant, A., Neill, C., Barends, R., Chiaro, B., Chen, Y., Feigl, L., Kelly, J., Lucero, E., Mariantoni, M., O’Malley, P. J. J. et al., “*Planar superconducting resonators with internal quality factors above one million,*” Appl. Phys. Lett. **100**, 113510 (2012).<a href="https://pubs.aip.org/aip/apl/article-abstract/100/11/113510/126200/Planar-superconducting-resonators-with-internal?redirectedFrom=fulltext" target="_blank" rel="noopener noreferrer"><i> View Reference</i></a>.<br>

Ohya, S., Chiaro, B., Megrant, A., Neill, C., Barends, R., Chen, Y., Kelly, J., Low, D., Mutus, J., O’Malley, P. J. J. et al., “*Room temperature deposition of sputtered TiN films for superconducting coplanar waveguide resonators,*” Supercond. Sci. Technol. **27**, 015009 (2013).<a href="https://iopscience.iop.org/article/10.1088/0953-2048/27/1/015009/meta" target="_blank" rel="noopener noreferrer"><i> View Reference</i></a>.<br>

Richardson, C. J. K., Siwak, N. P., Hackley, J., Keane, Z. K., Robinson, J. E., Arey, B., Arslan, I., and Palmer, B. S., “*Fabrication artifacts and parallel loss channels in metamorphic epitaxial aluminum superconducting resonators,*” Supercond. Sci. Technol. **29**, 064003 (2016).<a href="https://iopscience.iop.org/article/10.1088/0953-2048/29/6/064003" target="_blank" rel="noopener noreferrer"><i> View Reference</i></a>.<br>

Sage, J. M., Bolkhovsky, V., Oliver, W. D., Turek, B., and Welander, P. B., “*Study of loss in superconducting coplanar waveguide resonators,*” J. Appl. Phys. **109**, 063915 (2011).<a href="https://pubs.aip.org/aip/jap/article-abstract/109/6/063915/989262/Study-of-loss-in-superconducting-coplanar?redirectedFrom=fulltext" target="_blank" rel="noopener noreferrer"><i> View Reference</i></a>.<br>

Shi, Lili, Tingting Guo, Runfeng Su, Tianyuan Chi, Yifan Sheng, Junliang Jiang, Chunhai Cao, Jingbo Wu, Xuecou Tu, Guozhu Sun, Jian Chen, Peiheng Wu; "*Tantalum microwave resonators with ultra-high intrinsic quality factors,*" Appl. Phys. Lett. **12** , December 2022; 121 (24): 242601.<a href="https://pubs.aip.org/aip/apl/article-abstract/121/24/242601/2834741/Tantalum-microwave-resonators-with-ultra-high?redirectedFrom=fulltext" target="_blank" rel="noopener noreferrer"><i> View Reference</i></a>. <br>

Vissers, M. R., Gao, J., Wisbey, D. S., Hite, D. A., Tsuei, C. C., Corcoles, A. D., Steffen, M., and Pappas, D. P., “*Low loss superconducting titanium nitride coplanar waveguide resonators,*” Appl. Phys. Lett. **97**, 232509 (2010).<a href="https://pubs.aip.org/aip/apl/article-abstract/97/23/232509/325118/Low-loss-superconducting-titanium-nitride-coplanar?redirectedFrom=fulltext" target="_blank" rel="noopener noreferrer"><i> View Reference</i></a>.<br>

Vissers, M.R., J. Gao, D. S. Wisbey, D. A. Hite, C. C. Tsuei, A. D. Corcoles, M. Steffen, D. P. Pappas; "*Low loss superconducting titanium nitride coplanar waveguide resonators,*" Appl. Phys. Lett. **6** , December 2010; 97 (23): 232509. <a href="https://pubs.aip.org/aip/apl/article-abstract/97/23/232509/325118/Low-loss-superconducting-titanium-nitride-coplanar?redirectedFrom=fulltext" target="_blank" rel="noopener noreferrer"><i> View Reference</i></a>.<br>

Wang, H., Hofheinz, M., Wenner, J., Ansmann, M., Bialczak, R. C., Lenander, M., Lucero, E., Neeley, M., O’Connell, A. D., Sank, D. et al., “*Improving the coherence time of superconducting coplanar resonators,*” Appl. Phys. Lett. **95**, 233508 (2009).<a href="https://pubs.aip.org/aip/apl/article-abstract/95/23/233508/120944/Improving-the-coherence-time-of-superconducting?redirectedFrom=fulltext" target="_blank" rel="noopener noreferrer"><i> View Reference</i></a>.<br>

Wisbey, D. S., Gao, J., Vissers, M. R., da Silva, F. C. S., Kline, J. S., Vale, L., and Pappas, D. P., “*Effect of metal/substrate interfaces on radio-frequency loss in superconducting coplanar waveguides,*” J. Appl. Phys. **108**, 093918 (2010).<a href="https://pubs.aip.org/aip/jap/article-abstract/108/9/093918/345430/Effect-of-metal-substrate-interfaces-on-radio?redirectedFrom=fulltext" target="_blank" rel="noopener noreferrer"><i> View Reference</i></a>.<br>

Zheng K., D. Kowsari, N. J. Thobaben, X. Du, X. Song, S. Ran, E. A. Henriksen, D. S. Wisbey, K. W. Murch; "*Nitrogen plasma passivated niobium resonators for superconducting quantum circuits,*" Appl. Phys. Lett. **7** , March 2022; 120 (10): 102601.<a href="https://pubs.aip.org/aip/apl/article/120/10/102601/2833153/Nitrogen-plasma-passivated-niobium-resonators-for" target="_blank" rel="noopener noreferrer"><i> View Reference</i></a>.<br>
<br>
<br>
<br>
<br>
* * *
<!--<p><b>Check out our GitHub at </b><a href="https://github.com/Boulder-Cryogenic-Quantum-Testbed" target="_blank" rel="noopener noreferrer"><i>Boulder Cryogenic Quantum Testbed</i></a>.</p>-->
<!--<p style="text-align: center;"><b>Check out our GitHub at </b><a href="https://github.com/Boulder-Cryogenic-Quantum-Testbed" target="_blank" rel="noopener noreferrer"><i>Boulder Cryogenic Quantum Testbed</i></a>.</p>-->
### Relevant Links 
- [**McRae Lab Website**](https://www.colorado.edu/lab/mcrae/)
- [**BCQT Project Website**](https://www.nist.gov/programs-projects/boulder-cryogenic-quantum-testbed)
- [**BCQT GitHub Page**](https://github.com/Boulder-Cryogenic-Quantum-Testbed)<br>
![NOBG BCQT](https://github.com/DylanBlevins49/scresonators-lossdiagram/assets/120617602/e5a4fb56-1025-429b-b335-473f7bfc9f6b)




